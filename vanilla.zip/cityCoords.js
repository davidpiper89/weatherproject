export const adelaide = { long: 138.5953, lat: -34.9156}
export const brisbane = { long: 153.03743, lat: -27.486099}
export const geelong = { long: 144.350006, lat: -38.1580}
export const hobart = { long: 147.324997, lat: 42.8805546}
export const melbourne = { long: 144.983398, lat: -37.819954}
export const sydney = { long: 151.224121, lat: -33.891525}
export const perth = { long: 115.888138, lat: -31.9510296}

